"""Used for translating a string into a SymPy expression. """
